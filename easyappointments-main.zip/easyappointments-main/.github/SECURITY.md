# Security Vulnerabilities

If you discover a security vulnerability within Easy!Appointments, please send an email to info@easyappointments.org. 
All security vulnerabilities will be promptly addressed.
